CREATE PROCEDURE SP_Personalizacion_Alta_NM
    @Ropa VARCHAR(500),
    @Colores VARCHAR(250),
    @Accesorios VARCHAR(1000),
    @Papatines NVARCHAR(MAX) -- Lista de IDs de papatines separados por comas, ej: '1,2,3'
AS
BEGIN
    SET NOCOUNT ON;

    -- 1?? Insertar la nueva personalizaci�n
    INSERT INTO personalizacion (Ropa, Colores, Accesorios)
    VALUES (@Ropa, @Colores, @Accesorios);

    -- Obtener el ID reci�n insertado
    DECLARE @ID_personalizacion INT = SCOPE_IDENTITY();

    -- 2?? Asociar con los papatines usando la tabla intermedia
    DECLARE @xml XML = '<i>' + REPLACE(@Papatines, ',', '</i><i>') + '</i>';

    INSERT INTO PapatinPersonalizacion (ID_papatin, ID_personalizacion)
    SELECT x.i.value('.', 'INT') AS ID_papatin,
           @ID_personalizacion AS ID_personalizacion
    FROM @xml.nodes('/i') AS x(i);

    -- 3?? Devolver el ID creado
    SELECT @ID_personalizacion AS ID_personalizacion;
END;
