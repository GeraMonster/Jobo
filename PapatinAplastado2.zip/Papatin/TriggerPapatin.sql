CREATE TRIGGER Tr_Papatin_Alta
ON papatin 
AFTER INSERT
AS 
BEGIN 
	INSERT INTO papatinAuditoria(
		ID_papatinauditoria,
		Nombre, 
		Inventario,
		Puntuacion,
		Logros,
		FechaSincronizacion,
		Movimientoauditoria,
		Papatinauditoria,
		FechaAuditoria
	)
	SELECT 
		i.ID_papatin,
		i.Nombre,
		i.Inventario,
		i.Puntuacion,
		i.Logros,
		i.FechaSincronizacion,
		'A',
		CURRENT_USER,
		GETDATE()
	FROM INSERTED i;
END