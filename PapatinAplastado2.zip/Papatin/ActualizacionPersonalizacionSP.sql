﻿CREATE PROCEDURE SP_Actualizar_Personalizaciones
    @ID_papatin INT,
    @Personalizaciones NVARCHAR(MAX) -- Lista de IDs separados por comas, ej: '1,3,5'
AS
BEGIN
    SET NOCOUNT ON;

    -- 1️⃣ Eliminar las personalizaciones actuales de este papatín
    DELETE FROM PapatinPersonalizacion
    WHERE ID_papatin = @ID_papatin;

    -- 2️⃣ Insertar las nuevas personalizaciones
    DECLARE @xml XML = '<i>' + REPLACE(@Personalizaciones, ',', '</i><i>') + '</i>';

    INSERT INTO PapatinPersonalizacion (ID_papatin, ID_personalizacion)
    SELECT @ID_papatin AS ID_papatin,            -- Ahora incluimos la columna faltante
           x.i.value('.', 'INT') AS ID_personalizacion
    FROM @xml.nodes('/i') AS x(i);

END;
