CREATE VIEW V_Usuario
AS
SELECT ID_usuario,
Nombre,
Correo,
Edad,
FechaAlta
FROM usuario;
