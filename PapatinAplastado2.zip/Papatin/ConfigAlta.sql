CREATE PROCEDURE SP_ConfigApp_Alta
    @ID_usuario INT,
    @Notificaciones BIT = 1,
    @HorarioDormir TIME = '22:00:00',
    @HorarioDespertar TIME = '07:00:00'
AS
BEGIN
    SET NOCOUNT ON;

    -- Insertar nueva configuraci�n para el usuario
    INSERT INTO configuracionApp (
    ID_usuario, 
    Notifiaciones, 
    HorarioDormir, 
    HorarioDespertar
    )
    VALUES (
    @ID_usuario, 
    @Notificaciones, 
    @HorarioDormir, 
    @HorarioDespertar
    );

    -- Devolver el ID reci�n creado
    SELECT SCOPE_IDENTITY() AS ID_configuracion;
END;
