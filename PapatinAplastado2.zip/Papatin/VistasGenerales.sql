/*CREATE VIEW V_Usuario
AS
SELECT ID_usuario,
Nombre,
Correo,
Edad,
FechaAlta
FROM usuario;

CREATE VIEW V_Papatin
AS
SELECT ID_papatin,
       Nombre,
       Inventario,
       Puntuacion,
       Logros,
       FechaSincronizacion
FROM papatin;*/


