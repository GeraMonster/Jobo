﻿
use papatin;

/*create table usuario(
ID_usuario int primary key identity(1,1),
Nombre varchar(50) not null,
Correo varchar(50) unique,
Edad smallint not null check(edad > 0 and edad < 100),
FechaAlta datetime not null default getdate()
);

create table usuarioAuditoria(
ID_usuarioauditoria int primary key identity(1,1),
Nombre varchar(50),
Edad smallint, 
Correo varchar(50),
FechaAlta datetime default getdate(),
Movimientoauditoria varchar(1) not null, -- A = alta, B = baja, C = cambio
Usuarioauditoria varchar(100) not null,
FechaAuditoria datetime not null default getdate()
);

CREATE TABLE papatin (
    ID_papatin INT PRIMARY KEY IDENTITY(1,1),
    Nombre VARCHAR(50) NOT NULL,
    Inventario VARCHAR(1000) NOT NULL,
    Puntuacion BIGINT NOT NULL,
    Logros VARCHAR(1000) NOT NULL,
    FechaSincronizacion DATETIME NOT NULL DEFAULT GETDATE(),
    ID_usuario INT UNIQUE,  -- 1:1
    CONSTRAINT FK_Papatin_Usuario FOREIGN KEY (ID_usuario) REFERENCES usuario(ID_usuario)
);

create table configuracionApp(
ID_configuracion int primary key identity(1,1),
Notifiaciones bit not null default 1,
HorarioDormir time default '22:00:00',
HorarioDespertar time default '07:00:00',
ID_usuario int unique,
constraint FK_Configuracion_Usuario foreign key (ID_usuario) references usuario(ID_usuario)
);

create table papatinAuditoria(
ID_papatinauditoria int primary key identity(1,1),
Nombre varchar(50),
Inventario varchar(1000), 
Puntuacion bigint,
Logros varchar(1000),
FechaSincronizacion datetime default getdate(),
Movimientoauditoria varchar(1) not null, -- A = alta, B = baja, C = cambio
Papatinauditoria varchar(100) not null,
FechaAuditoria datetime not null default getdate()
);

create table personalizacion(
ID_personalizacion int primary key identity(1,1),
Ropa varchar(500),
Colores varchar(250),
Accesorios varchar(1000)
);

create table PapatinPersonalizacion (
    ID_papatin int not null,
    ID_personalizacion int not null,
    primary key (ID_papatin, ID_personalizacion),
    foreign key (ID_papatin) REFERENCES papatin(ID_papatin),
    foreign key (ID_personalizacion) REFERENCES personalizacion(ID_personalizacion)
);*/