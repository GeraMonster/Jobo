CREATE PROCEDURE SP_Papatin_AsignarConfiguracion
    @ID_papatin INT,
    @ID_configuracion INT
AS
BEGIN
    SET NOCOUNT ON;

    UPDATE papatin
    SET ID_configuracion = @ID_configuracion
    WHERE ID_papatin = @ID_papatin;
END;
