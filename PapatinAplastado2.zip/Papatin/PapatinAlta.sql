CREATE PROCEDURE SP_Papatin_Alta
   @Nombre varchar(50),
   @Inventario varchar(1000),
   @Puntuacion bigint,
   @Logros varchar(1000)
AS
BEGIN
    INSERT INTO papatin(
       Nombre,
       Inventario,
       Puntuacion,
       Logros
    )
    VALUES (
        @Nombre,
        @Inventario,
        @Puntuacion,
        @Logros
    );
END;