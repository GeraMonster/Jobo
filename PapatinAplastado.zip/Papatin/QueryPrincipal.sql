
use papatin;

create table usuario(
ID_usuario int primary key identity(1,1),
Nombre varchar(50) not null,
Correo varchar(50) unique,
Edad smallint not null check(edad > 0 and edad < 100),
FechaAlta datetime not null default getdate()
);

create table usuarioAuditoria(
ID_usuarioauditoria int primary key identity(1,1),
Nombre varchar(50),
Edad smallint, 
Correo varchar(50),
FechaAlta datetime default getdate(),
Movimientoauditoria varchar(1) not null, -- A = alta, B = baja, C = cambio
Usuarioauditoria varchar(100) not null,
FechaAuditoria datetime not null default getdate()
);
