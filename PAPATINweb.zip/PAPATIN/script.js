function iniciarSesion() {
  const usuario = document.getElementById("usuarioLogin").value;
  const clave = document.getElementById("claveLogin").value;

  if (usuario.length < 4 || clave.length < 4) {
    alert("COMPROBAR CONTRASEÑA");
    return false;
  }

  // Simular que el usuario está iniciando sesión
  localStorage.setItem("usuarioPapatin", usuario);
  localStorage.setItem("modoPapatin", "login");
  window.location.href = "welcome.html";
  return false;
}

function registrarse() {
  const usuario = document.getElementById("usuarioRegistro").value;
  const clave = document.getElementById("claveRegistro").value;

  if (usuario.length < 4 || clave.length < 4) {
    alert("El usuario y la contraseña deben tener al menos 4 caracteres.");
    return false;
  }

  // Simular registro
  localStorage.setItem("usuarioPapatin", usuario);
  localStorage.setItem("modoPapatin", "registro");
  window.location.href = "welcome.html";
  return false;
}
