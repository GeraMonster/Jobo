CREATE PROCEDURE SP_Tienda_Actualizar
    @Accion NVARCHAR(10),         -- 'INSERT', 'UPDATE' o 'DELETE'
    @ID_tienda INT = NULL,        -- Necesario para UPDATE/DELETE
    @Objetos VARCHAR(1500) = NULL,
    @precioObjeto DECIMAL = NULL
AS
BEGIN
    SET NOCOUNT ON;

    IF @Accion = 'INSERT'
    BEGIN
        INSERT INTO tienda (Objetos, precioObjeto)
        VALUES (@Objetos, @precioObjeto);

        SELECT SCOPE_IDENTITY() AS NuevoID_tienda;
    END

    ELSE IF @Accion = 'UPDATE'
    BEGIN
        IF @ID_tienda IS NULL
        BEGIN
            RAISERROR('Debes especificar el ID_tienda para actualizar.', 16, 1);
            RETURN;
        END

        UPDATE tienda
        SET Objetos = ISNULL(@Objetos, Objetos),
            precioObjeto = ISNULL(@precioObjeto, precioObjeto)
        WHERE ID_tienda = @ID_tienda;
    END

    ELSE IF @Accion = 'DELETE'
    BEGIN
        IF @ID_tienda IS NULL
        BEGIN
            RAISERROR('Debes especificar el ID_tienda para eliminar.', 16, 1);
            RETURN;
        END

        DELETE FROM tienda
        WHERE ID_tienda = @ID_tienda;
    END

    ELSE
    BEGIN
        RAISERROR('Acci�n no v�lida. Usa INSERT, UPDATE o DELETE.', 16, 1);
    END
END;
GO
