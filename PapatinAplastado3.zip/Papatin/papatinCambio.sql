CREATE PROCEDURE SP_Papatin_Cambio
    @ID_papatin INT,
    @Nombre     VARCHAR(50) = NULL,
    @Inventario     varchar(1000) = NULL, 
    @Puntuacion     bigint = NULL,
    @Logros varchar(1000),
    @Monedas int
AS
BEGIN
    IF @Nombre IS NOT NULL
    BEGIN
        UPDATE papatin
        SET Nombre = @Nombre
        WHERE ID_papatin = @ID_papatin;
    END;

    IF @Inventario IS NOT NULL
    BEGIN
        UPDATE papatin
        SET Inventario = @Inventario
        WHERE ID_papatin = @ID_papatin;
    END;

    IF @Puntuacion IS NOT NULL
    BEGIN
        UPDATE papatin
        SET Puntuacion = @Puntuacion
        WHERE ID_papatin = @ID_papatin;
    END;
    IF @Logros IS NOT NULL
    BEGIN
        UPDATE papatin
        SET Logros = @Logros
        WHERE ID_papatin = @ID_papatin;
    END;
    IF @Monedas IS NOT NULL
    BEGIN
        UPDATE papatin
        SET Monedas = @Monedas
        WHERE ID_papatin = @ID_papatin;
    END;
END;

