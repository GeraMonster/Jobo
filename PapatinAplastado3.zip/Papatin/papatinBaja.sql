CREATE PROCEDURE SP_Papatin_Baja
    @ID_papatin INT
AS
BEGIN
    DELETE FROM papatin
    WHERE ID_papatin = @ID_papatin;
END;